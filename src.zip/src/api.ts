import { Ticket, TicketsResponse } from './types';

const API_BASE = import.meta.env.VITE_API_BASE || 'http://localhost:4000';

export async function fetchTickets(
  search: any = '',
  sortOrder: 'asc' | 'desc' = 'desc'
): Promise<TicketsResponse> {
  const safeSearch =
    typeof search === 'string'
      ? search
      : String(search ?? '');

  const params = new URLSearchParams();

  if (safeSearch.trim()) {
    params.append('search', safeSearch.trim());
  }

  params.append('sort', 'priority');
  params.append('order', sortOrder);

  const response = await fetch(
    `${API_BASE}/tickets?${params.toString()}`
  );

  const data = await response.json().catch(() => null);

  if (!response.ok) {
    throw new Error(
      data?.message || 'Failed to load tickets'
    );
  }

  return data;
}

export async function createTicket(
  ticket: Omit<Ticket, '_id' | 'createdAt'>
): Promise<Ticket> {
  console.log('Sending Ticket:', ticket);

  const response = await fetch(`${API_BASE}/tickets`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(ticket),
  });

  const data = await response.json().catch(() => null);

  console.log('Response Status:', response.status);
  console.log('Response Data:', data);

  if (!response.ok) {
    throw new Error(
      data?.message || 'Could not create ticket'
    );
  }

  return data;
}

export async function deleteTicket(id: string): Promise<void> {
  const response = await fetch(`${API_BASE}/tickets/${id}`, {
    method: 'DELETE',
  });

  const data = await response.json().catch(() => null);

  if (!response.ok) {
    throw new Error(
      data?.message || 'Could not delete ticket'
    );
  }
}